const fs = require('fs');
const util = require('util');

const unlinkAsync = util.promisify(fs.unlink);

async function deleteFile(filePath) {
    try {
        await unlinkAsync(filePath);  
        console.log(`${filePath} was deleted successfully.`);
    } catch (error) {
        console.error(`Error deleting ${filePath}:`, error.message);
    }
}

deleteFile('example.txt');
