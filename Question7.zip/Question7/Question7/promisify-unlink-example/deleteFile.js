const fs = require('fs');
const util = require('util');

// Promisify fs.unlink
const unlinkAsync = util.promisify(fs.unlink);

// Async function to delete a file
async function deleteFile(filePath) {
    try {
        await unlinkAsync(filePath);  // Wait for the file to be deleted
        console.log(`${filePath} was deleted successfully.`);
    } catch (error) {
        console.error(`Error deleting ${filePath}:`, error.message);
    }
}

// Call the delete function for 'example.txt'
deleteFile('example.txt');
