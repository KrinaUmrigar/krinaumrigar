1)install the following package and check if it is available in package.json or not

npm install readline-sync

2)type on  prompt like this 

Welcome to the Customer Support Chatbot! Type 'exit' to quit.
You: Hi
Chatbot: Hello! How can I assist you today?
You: What is my order status?
Chatbot: Your order is on the way!
You: Cancel my order.
Chatbot: Sorry, the cancellation window has passed.
You: Bye
Chatbot: Goodbye! Have a great day!
