// server.js
const express = require('express');
const axios = require('axios');
const app = express();
const port = 3001;

// Replace with a valid cricket API URL
const CRICKET_API_URL = 'https://cricapi.com/api/cricket?apikey=YOUR_API_KEY'; // Replace YOUR_API_KEY

// Serve static files from the "public" directory
app.use(express.static('public'));

// Route to get live cricket scores
app.get('/live-scores', async (req, res) => {
    try {
        const response = await axios.get(CRICKET_API_URL);
        const scores = response.data; // Check the structure of the response
        res.json(scores);
    } catch (error) {
        console.error('Error fetching live scores:', error.message);
        console.error('Error details:', error.response ? error.response.data : error);
        res.status(500).send('Error fetching live scores');
    }
});

// Start the server
app.listen(port, () => {
    console.log(`Server running at http://localhost:${port}`);
});
