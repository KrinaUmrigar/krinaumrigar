const express = require("express");
const path = require("path");
const bodyParser = require("body-parser");

const app = express();
const PORT = 3000;

// Serve static resources from the "public" folder
app.use(express.static(path.join(__dirname, "public")));

// Use body-parser middleware to handle JSON data from POST requests
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

// Handle GET request to "/"
app.get("/", (req, res) => {
  res.sendFile(path.join(__dirname, "public", "index.html"));
});

// Handle GET request to "/api/data"
app.get("/api/data", (req, res) => {
  const data = { message: "This is data from the server!" };
  res.json(data);
});

// Handle POST request to "/api/submit"
app.post("/api/submit", (req, res) => {
  const { name, email } = req.body;
  console.log(`Received data: Name = ${name}, Email = ${email}`);
  // Send the received data back to the client
  res.json({ success: true, message: "Data received successfully!", data: { name, email } });
});

// Start the server
app.listen(PORT, () => {
  console.log(`Server running at http://localhost:${PORT}`);
});
