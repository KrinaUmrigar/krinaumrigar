const responses = {
    greeting: ["Hello! How can I assist you today?", "Hi there! Need any help?"],
    order_status: [
      "Your order is being processed.",
      "Your order is on the way!",
      "Order ID not found. Please check and try again.",
    ],
    cancel_order: [
      "Your order has been canceled.",
      "Sorry, the cancellation window has passed.",
    ],
    goodbye: ["Goodbye! Have a great day!", "See you soon!"],
    fallback: ["I'm sorry, I didn't understand that. Can you rephrase?"],
  };
  
  function getResponse(input) {
    const lowerInput = input.toLowerCase();
  
    if (lowerInput.includes("hello") || lowerInput.includes("hi")) {
      return randomResponse(responses.greeting);
    } else if (lowerInput.includes("order status")) {
      return randomResponse(responses.order_status);
    } else if (lowerInput.includes("cancel order")) {
      return randomResponse(responses.cancel_order);
    } else if (lowerInput.includes("bye") || lowerInput.includes("goodbye")) {
      return randomResponse(responses.goodbye);
    } else {
      return randomResponse(responses.fallback);
    }
  }
  
  function randomResponse(arr) {
    return arr[Math.floor(Math.random() * arr.length)];
  }
  
  module.exports = getResponse;
  